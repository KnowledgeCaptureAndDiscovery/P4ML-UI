#!/usr/bin/env bash

python src/pipeline.py