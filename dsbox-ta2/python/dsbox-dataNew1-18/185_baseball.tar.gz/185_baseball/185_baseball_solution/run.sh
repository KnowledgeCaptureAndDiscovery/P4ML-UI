#!/usr/bin/env bash

python src/pipeline.py ../185_baseball_dataset ../185_baseball_problem
